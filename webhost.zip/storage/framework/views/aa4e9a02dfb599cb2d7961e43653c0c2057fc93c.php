<ul class="navbar-nav  justify-content-end">
    <li class="nav-item d-flex align-items-center" style="margin-right: 10px">
        <a href="<?php echo e(route('profile', Auth::user()->id)); ?>" class="nav-link text-body font-weight-bold px-0">
            <i class="fa fa-user me-sm-1"></i>
            <span class="d-sm-inline d-none"><?php echo e(Auth::user()->name); ?></span>
        </a>
    </li>
    <li class="nav-item d-flex align-items-center">
        <a href="<?php echo e(route('logout')); ?>">
            <img src="<?php echo e(asset('dashboard/assets/img/logout.svg')); ?>"  alt="" data-toggle="tooltip" data-placement="top" title="Đăng xuất">
        </a>
    </li>
</ul><?php /**PATH D:\xampp\htdocs\webhost\resources\views/admin/info.blade.php ENDPATH**/ ?>